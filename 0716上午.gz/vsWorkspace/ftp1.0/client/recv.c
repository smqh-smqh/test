#define _XOPEN_SOURCE
#define _GNU_SOURCE
#include "func.h"

//产生长度为length的随机字符串
int getRomdomString(int length,char* salt){
    int i,flag;
    salt[0]='$';
    salt[1]='6';
    salt[2]='$';
    srand(time(NULL));
    for(i=3;i<length;i++){
        printf("%d\n",i);
        flag=rand()%3;
        switch(flag){
        case 1:
        salt[i]='A'+rand()%26;
        break;
        case 2:
        salt[i]='a'+rand()%26;
        break;
        case 0:
        salt[i]='0'+rand()%10;
        break;
        }
    }
    printf("%d\n",i);
    printf("%s\n",salt);
    return 0;
}

int clogin(int fd){
    char username[20]={0};
    char *password;
    char *password2;
    char salt[12]={0};
    char flag='0';//user exist or not
start:
    printf("please enter username(no more than 20):");
    scanf("%s",username);
    //printf("%s\n",username);
    send(fd,username,strlen(username),0);
    recv(fd,&flag,1,0);
    if(flag=='1'){
        password=getpass("please enter password:\n");
        //scanf("%s",password);
        //encrypt process
        printf("login sucess\n");
    }else{
        printf("this user do not exist,register?(y/n)\n");
        read(STDIN_FILENO,&flag,1);
        send(fd,flag,1,0);
        if(flag=='y'){
twopasswd:
            password=getpass("please enter password:");
            //printf("%s\n",password);
            char pw[10]={0};
            strcpy(pw,password);
            //printf("pw=%s\n",pw);
            password2=getpass("please enter password again:");
            //printf("%s\n",password2);            
            char pw2[10]={0};
            strcpy(pw2,password2);
            //printf("pw2=%s\n",pw2);
            if(!strcmp(pw,pw2)){
                //insert into database
                getRomdomString(11,salt);
                send(fd,salt,11,0);
                char* lcrypt;
                lcrypt=crypt(pw,salt);
                send(fd,strlen(lcrypt),4,0);
                send(fd,lcrypt,strlen(lcrypt),0);
                printf("%s\n",lcrypt);
                printf("%ld\n",strlen(lcrypt));
                printf("register success\n");
                goto start;

            }else{
                printf("two password do not match,please enter again\n");
                goto twopasswd;
            }
        }
        else{
            printf("please enter again\n");
            goto start;
        }
    }
    return 0;
}

int recvCycle(int socketFd,void* buf,int len){
    int ret,downSize=0;
    char* p=(char*)buf;
    while(downSize<len){
        ret=recv(socketFd,p+downSize,len-downSize,0);
        if(-1==ret){return -1;}
        downSize+=ret;
    }
    return downSize;
}

int myRecv(int socketFd){
    int len,fd,ret;
    char buf[1000];
    bzero(buf,sizeof(buf));
    recvCycle(socketFd,&len,4);
    recvCycle(socketFd,buf,len);
    printf("buf=%s\n",buf);
    //create file
    fd=open(buf,O_RDWR|O_CREAT,0666);
    ERROR_CHECK(fd,-1,"open");

    //file size
    off_t filesize;
    recvCycle(socketFd,&len,4);
    recvCycle(socketFd,&filesize,len);
    printf("filesize=%ld\n",filesize);

    //file content
    off_t slice=filesize/1000,downLoadSize=0,lastSize=0;
    struct timeval start,end;
    gettimeofday(&start,NULL);

    //*************way1**************
    recvCycle(socketFd,&len,4);
    while(len){
        ret=recvCycle(socketFd,&buf,len);
        if(-1==ret){return -1;}
        write(fd,buf,len);
        downLoadSize+=ret;
        if(downLoadSize-lastSize>slice)
        {
            printf("%5.2f%%\r",(float)downLoadSize/filesize*100);
            fflush(stdout);
            lastSize=downLoadSize;
        }
        //printf("%ld %ld %ld\n",downLoadSize,lastSize,slice);
        recvCycle(socketFd,&len,4);
    }

    //*************way2**************
    /* ftruncate(fd,filesize);
    char *p=mmap(NULL,filesize,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    ERROR_CHECK(p,(char*)-1,"mmap");
    recvCycle(socketFd,p,filesize);
    munmap(p,filesize); */

    //*************way3**************
    /* int fds[2];
    pipe(fds);
    while(downLoadSize<filesize){
        ret=splice(socketFd,NULL,fds[1],NULL,65535,SPLICE_F_MOVE|SPLICE_F_MORE);
        ERROR_CHECK(ret,-1,"splice");
        ret=splice(fds[0],NULL,fd,NULL,65535,SPLICE_F_MOVE|SPLICE_F_MORE);
        ERROR_CHECK(ret,-1,"splice");
        downLoadSize+=ret;
        if(downLoadSize-lastSize>slice)
        {
            printf("%5.2f%%\r",(float)downLoadSize/filesize*100);
            fflush(stdout);
            lastSize=downLoadSize;
        }
    } */
    gettimeofday(&end,NULL);
    printf("100.00%%\n");
    printf("use time=%ld\n",(end.tv_sec-start.tv_sec)*1000000+end.tv_usec-start.tv_usec);
    return 0;
}