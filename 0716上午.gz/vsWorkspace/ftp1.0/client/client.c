#include "func.h"
int clogin(int socketFd);

int epollAdd(int epfd,int fd){
    int ret;
    struct epoll_event ev;
    ev.events=EPOLLIN;
    ev.data.fd=fd;
    ret=epoll_ctl(epfd,EPOLL_CTL_ADD,fd,&ev);
    ERROR_CHECK(ret,-1,"epoll_ctl");
    return 0;
}

int main(int argc,char* argv[]){
    if(argc!=3){
        printf("./ftp_client 192.168.5.151 2000\n");
        return -1;
    }
    int socketFd;
    socketFd=socket(AF_INET,SOCK_STREAM,0);
    ERROR_CHECK(socketFd,-1,"socket");
    struct sockaddr_in cAddr;
    cAddr.sin_family=AF_INET;
    cAddr.sin_addr.s_addr=inet_addr(argv[1]);
    cAddr.sin_port=ntohs(atoi(argv[2]));

    int ret,epfd;
    char buf[20];
    connect(socketFd,(struct sockaddr*)&cAddr,sizeof(struct sockaddr));
    clogin(socketFd);

    epfd=epoll_create(1);
    struct epoll_event evs[2];
    epollAdd(epfd,socketFd);
    epollAdd(epfd,STDIN_FILENO);
    int i,n;
    while(1){
        n=epoll_wait(epfd,evs,3,-1);
        for(i=0;i<n;i++){
            if(evs[i].data.fd==socketFd){
                bzero(buf,sizeof(buf));
                ret=recv(socketFd,buf,sizeof(buf),0);
                if(0==ret){goto end;}
                printf("%s\n",buf);
            }
            if(evs[i].data.fd==STDIN_FILENO){
                bzero(buf,sizeof(buf));
                ret=read(0,buf,sizeof(buf));
                if(0==ret){
                    goto end;
                }
                ret=send(socketFd,buf,strlen(buf)-1,0);
                ERROR_CHECK(ret,-1,"send");
            }
        }        
    }
end:
    close(epfd);
    close(socketFd);
    return 0;
}