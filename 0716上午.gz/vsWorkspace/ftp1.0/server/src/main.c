#include "../include/head.h"

int main(int argc,char* argv[]){
    if(argc!=2){
        printf("./ftp_server ../conf/server.conf\n");
        return -1;
    }

    char* ip=(char*)calloc(1,20);
    char* port=(char*)calloc(1,20);
    openConf(argv[1],ip,port);
    //printf("ip=%s,port=%s",ip,port);
    
    int socketFd,ret;   
    tcp_init(&socketFd,ip,port);
    mysqlInit();

    int newFd;
    char buf[50];
    int epfd;
    epfd=epoll_create(1);
    struct epoll_event evs[3];
    epollAdd(epfd,socketFd);
    epollAdd(epfd,STDIN_FILENO);
    int i,n;
    while(1){
        n=epoll_wait(epfd,evs,3,-1);
        for(i=0;i<n;i++){
            if(evs[i].data.fd==socketFd){
                newFd=accept(socketFd,NULL,NULL);
                while(1){
                    if(!slogin(newFd)){
                        break;
                    }
                    if(1==slogin(newFd)){
                        goto close;
                    }
                }
                epollAdd(epfd,newFd);
            }
            if(evs[i].data.fd==newFd){
                bzero(buf,sizeof(buf));
                ret=recv(newFd,buf,sizeof(buf),0);
                if(0==ret){
                    epollDel(epfd,newFd);
close:
                    close(newFd);
                    break;
                }
                printf("%s\n",buf);
                ret=process(buf);
                sendResult(newFd,ret);                
            }
            if(evs[i].data.fd==STDIN_FILENO){
                bzero(buf,sizeof(buf));
                ret=read(0,buf,sizeof(buf));
                if(0==ret){
                    goto end;
                }
                ret=send(newFd,buf,strlen(buf)-1,0);
                ERROR_CHECK(ret,-1,"send");
            }
        }
    }
end:
    mysql_close(conn);
    close(epfd);
    close(socketFd);
    return 0;
}