#include "../include/head.h"

int tcp_init(int* socketFd,char* ip,char* port){
    int newSocketFd;
    newSocketFd=socket(AF_INET,SOCK_STREAM,0);
    ERROR_CHECK(newSocketFd,-1,"socket");
    int ret,reuse=1;
    ret=setsockopt(newSocketFd,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(reuse));
    ERROR_CHECK(ret,-1,"setsockopt");
    struct sockaddr_in serAddr;
    bzero(&serAddr,sizeof(serAddr));
    serAddr.sin_family=AF_INET;
    serAddr.sin_port=htons(atoi(port));
    serAddr.sin_addr.s_addr=inet_addr(ip);
    ret=bind(newSocketFd,(struct sockaddr*)&serAddr,sizeof(serAddr));
    ERROR_CHECK(ret,-1,"bind");
    listen(newSocketFd,10);
    *socketFd=newSocketFd;
    return 0;
}

int openConf(char* file,char* ip,char* port){
    FILE *confFd;
    confFd=fopen(file,"r");
    char buf[20];
    char ar[2][20];
    bzero(buf,sizeof(buf));
    bzero(ar,sizeof(ar));
    int i=0,j=0,k=0;
    while(fgets(buf,20,confFd)){
        //printf("%s",buf);
        j=k=0;      
        while(buf[j]!='='){
            j++;
        }
        j++;
        for(;j<strlen(buf)-1;j++){
                ar[i][k]=buf[j];
                k++;
        }
        //printf("%s\n",ar[i]);
        i++;
    }
    strcpy(ip,ar[0]);
    strcpy(port,ar[1]);
    fclose(confFd);
    return 0;
}

int slogin(int newFd){
    char buf[20]={0};
    int ret;
    char *salt,*lcrypt;
    char flag;
    char query[50];
    train_t t;
start:
    bzero(query,sizeof(query));
    strcpy(query,"select username from ftp_user where username='");   
    ret=recv(newFd,buf,sizeof(buf),0);
    if(0==ret){return 1;}
    sprintf(query,"%s%s%s",query,buf,"'");
    printf("%s\n",query);
    if(1==mysql_select(query,buf)){
        printf("select successs\n");
        send(newFd,"1",1,0);
        return 0;
    }    
    else {
        printf("select fail\n");
        send(newFd,"0",1,0);
        recv(newFd,&flag,1,0);
        if(flag=='1'){
        recv(newFd,salt,11,0);
        printf("%s\n",salt);
        recv(newFd,&t.length,11,0);
        printf("%d\n",t.length);
        recv(newFd,lcrypt,t.length,0);
        printf("%s\n",lcrypt);
        }else{
            goto start;
        }
        return -1;
    }
    //password
    //char query[50]="insert into ftp_user(name) values('";
    //sprintf(query,"%s%s%s",query,username,"')");
    bzero(buf,sizeof(buf));
    ret=recv(newFd,buf,sizeof(buf),0);
    if(0==ret){return 1;}

}

int epollAdd(int epfd,int fd){
    int ret;
    struct epoll_event ev;
    ev.events=EPOLLIN;
    ev.data.fd=fd;
    ret=epoll_ctl(epfd,EPOLL_CTL_ADD,fd,&ev);
    ERROR_CHECK(ret,-1,"epoll_ctl");
    return 0;
}

int epollDel(int epfd,int fd){
    int ret;
    struct epoll_event ev;
    ev.events=EPOLLIN;
    ev.data.fd=fd;
    ret=epoll_ctl(epfd,EPOLL_CTL_DEL,fd,&ev);
    ERROR_CHECK(ret,-1,"epoll_ctl");
    return 0;
}

int process(char* buf){
    char command[7]={0};
    char detail[30]={0};
    int i=0,j=0,k=0;
    while(buf[i]!=' '){
        if(buf[i]==0){break;}
        //printf("buf[%d]=%c\n",i,buf[i]);
        i++;
        if(i>=7){
            printf("unkown command\n");
            return -1;
        }        
    }
    //splite command
    for(j=0;j<i;j++){
        command[j]=buf[j];
        //printf("%c\n",command[j]);
    }
    
    for(j=i+1;j<strlen(buf);j++){
        //printf("j=%d k=%d\n",j,k);
        detail[k]=buf[j];
        //printf("%c\n", detail[k]);
        k++;
    }
    //printf("command=%s\n",command);
    //printf("detail=%s\n",detail);

    if(!strcmp(command,"ls")){if(!myls()){return 1;};}
    else if(!strcmp(command,"cd")){if(!mycd(detail)){return 2;};}
    else if(!strcmp(command,"puts")){if(!myputs(detail)){return 3;};}
    else if(!strcmp(command,"gets")){if(!mygets(detail)){return 4;};}
    else if(!strcmp(command,"rm")){if(!myrm(detail)){return 5;};}
    else if(!strcmp(command,"pwd")){if(!mypwd(detail)){return 6;};}
    else if(!strcmp(command,"mkdir")){if(!mymkdir(detail)){return 7;};}
    else if(!strcmp(command,"touch")){if(!mytouch(detail)){return 8;};}
    else{
        printf("unkown command\n");
        return -1;
    }
    return 0;
}

int myls(){
    
    printf("ls\n");
    return 0;
}
int mycd(char* detail){
    printf("cd\n");
    return 0;
}
int myputs(char* detail){
    printf("puts\n");
    return 0;
}
int mygets(char* detail){
    printf("gets\n");
    return 0;
}
int myrm(char* detail){
    printf("rm\n");
    return 0;
}
int mypwd(char* detail){
    printf("pwd\n");
    return 0;
}
int mymkdir(char* detail){
    printf("mkdir\n");
    return 0;
}
int mytouch(char* detail){
    printf("touch\n");
    return 0;
}

int sendResult(int newFd,int ret){
    int k;
    switch(ret){
        case 1:
        k=send(newFd,"ls success",11,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 2:
        k=send(newFd,"cd success",11,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 3:
        k=send(newFd,"puts success",13,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 4:
        k=send(newFd,"gets success",13,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 5:
        k=send(newFd,"rm success",11,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 6:
        k=send(newFd,"pwd success",12,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 7:
        k=send(newFd,"mkdir success",14,0);
        ERROR_CHECK(k,-1,"send");
        break;
        case 8:
        k=send(newFd,"touch success",14,0);
        ERROR_CHECK(k,-1,"send");
        break;
        default:
        k=send(newFd,"fail",5,0);
        ERROR_CHECK(k,-1,"send");
        break;
    }
    return 0;
}
