#ifndef _HEAD_H_
#define _HEAD_H_

#include "func.h"
MYSQL *conn;
MYSQL_RES *res;
MYSQL_ROW row;

typedef struct{
    int length;
    char buf[100];
}train_t,*pTrain_t;

typedef struct{
    char abdir[50];
    int preCode;
    int code;
    char filename[30];
    char MD5[32];
    char owner[20];
    off_t filesize;
    char fileType;
}file_info,*pfile_info;

int tcp_init(int*,char*,char*);
int openConf(char* file,char* ip,char* port);
int slogin(int);
int getRomdomString(int length,char* salt);
int epollAdd(int epfd,int fd);
int epollDel(int epfd,int fd);
int process(char*);
int myls();
int mycd(char* detail);
int mygets(char* detail);
int myputs(char* detail);
int myrm(char* detail);
int mypwd(char* detail);
int mymkdir(char* detail);
int mytouch(char* detail);

int sendResult(int newfd,int ret);

int mysqlInit();
int mysql_insert(char* query);
int mysql_update(char* query);
int mysql_delete(char* query);
int mysql_select(char* query,char* condt);

int md5sum(char *file_path);

#endif